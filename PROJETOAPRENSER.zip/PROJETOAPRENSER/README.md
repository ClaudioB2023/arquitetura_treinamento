# 🚀 Projeto Aprenser
Desenvolvimento de uma página com link direcionado. Aplicação de conceitos normalize.css, e conceitos de reset.CSS

## 🔧 Trabalhando com:
 
Div's, Classes, Article, Parágrafo, Fonts do Google, Imagens, Padding, Responsividade, Padding, Nav, Footer.

